# Update auf GitHub hochladen

Vorher: In der alten App unter **Einstellungen → Backup** ein Backup erstellen (zur Sicherheit).

1. ZIP entpacken.
2. Auf github.com dein Repository öffnen → **Add file → Upload files**.
3. Den **Inhalt** des Ordners hineinziehen (`www`, `assets`, `signing`, `.github`, `patch.py`, `package.json`, `capacitor.config.json`, `.gitignore`).
   - Gleiche Dateien werden ersetzt. Bei späteren Updates reicht **`www/index.html`**.
   - Der Ordner `.github` ist auf manchen Systemen versteckt. Falls er sich nicht hochladen lässt: **Add file → Create new file**, als Namen `.github/workflows/android.yml` eintippen und den Inhalt der Datei einfügen. Hast du schon einen Workflow, der funktioniert, lass ihn so.
4. Unten **Commit changes** (direkt auf `main`).
5. Oben auf **Actions** gehen: „Android APK bauen“ läuft ca. 5–10 Minuten (grüner Haken = fertig).
6. APK holen: rechts im Repository unter **Releases** (neuester Build) → `Meine-Rezepte.apk` auf dem Handy herunterladen und öffnen. Alternativ in der Actions-Ausführung unter **Artifacts**.
7. Installieren **über die alte App** (gleiche Signatur): Rezepte bleiben erhalten und werden beim ersten Start automatisch in den neuen Speicher übernommen.

Hinweis: Online-Nährwerte (Open Food Facts / USDA) und YouTube-Vorschaubilder brauchen Internet und funktionieren nur in der App.
