import pathlib, os, re
# 1) Feste Signatur, damit Updates über die alte App installiert werden können (Daten bleiben erhalten)
g=pathlib.Path("android/app/build.gradle"); s=g.read_text()
if "rezepte.keystore" not in s:
    s=s.replace("android {",'android {\n    signingConfigs {\n        debug {\n            storeFile file("${rootDir}/../signing/rezepte.keystore")\n            storePassword "rezepte123"\n            keyAlias "rezepte"\n            keyPassword "rezepte123"\n        }\n    }',1)
    print("Signatur gesetzt")
# 2) Versionsnummer pro Build erhöhen (Android verlangt das für Updates)
n=os.environ.get("GITHUB_RUN_NUMBER")
if n:
    code=10000+int(n)
    s=re.sub(r"versionCode\s+\d+","versionCode %d"%code,s,count=1)
    s=re.sub(r'versionName\s+"[^"]*"','versionName "1.1.%s"'%n,s,count=1)
    print("versionCode",code)
g.write_text(s)
# 3) Helle Status- und Navigationsleiste im Design der App
st=pathlib.Path("android/app/src/main/res/values/styles.xml"); x=st.read_text()
add='<item name="android:background">@null</item>\n        <item name="android:statusBarColor">#F4F2EE</item>\n        <item name="android:navigationBarColor">#F4F2EE</item>\n        <item name="android:windowLightStatusBar">true</item>\n        <item name="android:windowLightNavigationBar">true</item>'
if "statusBarColor" not in x and '<item name="android:background">@null</item>' in x:
    st.write_text(x.replace('<item name="android:background">@null</item>',add,1)); print("Leisten gesetzt")
